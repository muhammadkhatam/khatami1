package com.example.flutter_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
