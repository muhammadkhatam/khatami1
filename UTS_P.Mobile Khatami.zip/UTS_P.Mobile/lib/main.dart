import 'package:flutter/material.dart';

void main() => runApp(CardProfile());

class CardProfile extends StatelessWidget {
  const CardProfile({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.teal,
        body: SafeArea(child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 50.0,
              backgroundImage: AssetImage('asset/img/Khatami.jpg'),
            ),
            Text('Khatami', 
            style: TextStyle(
              fontFamily: 'Spider Home',
              fontSize: 40.0,
              color: Colors.white,
              fontWeight: FontWeight.bold),
            ),
          Text('Flutter Developers', style: TextStyle(
            fontFamily: 'Spider Home',
            color: Colors.teal.shade100,
            fontSize: 20.0,
            letterSpacing: 2.5,
            fontWeight: FontWeight.bold
          ),
          ),
          SizedBox(
            height: 50.0,
            width: 150.0,
            child: Divider(
              color: Colors.teal.shade100,
            ),
          ),
          Card(
            margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
            child: ListTile(
              leading: Icon(
                Icons.phone,
                color: Colors.teal,
              ),
            title: Text('+62 0851 9778 6969', style: TextStyle(
              color: Colors.teal.shade900,
              fontFamily: 'Spider Home',
              fontSize: 20.0),
              ),
            ),
          ),
          Card(
            margin: EdgeInsets.symmetric(
              vertical: 10.0, 
              horizontal: 25.0,
            ),
             child: ListTile(
               leading: Icon(
                 Icons.email,
                 color: Colors.teal,
               ),
             title: Text('Khatami897@gmail.com',
             style: TextStyle(
               fontSize: 20.0,
               color: Colors.teal.shade900,
               fontFamily: 'Spider Home'),
             ),
             ),
          ),
          Card(
            margin: EdgeInsets.symmetric(
              vertical: 10.0, 
              horizontal: 25.0,
            ),
             child: ListTile(
               leading: Icon(
                 Icons.home,
                 color: Colors.teal,
               ),
             title: Text('Banjarbaru, Kom Permata indah',
             style: TextStyle(
               fontSize: 20.0,
               color: Colors.teal.shade900,
               fontFamily: 'Spider Home'),
             ),
             ),
          ),
           Card(
            margin: EdgeInsets.symmetric(
              vertical: 10.0, 
              horizontal: 25.0,
            ),
             child: ListTile(
               leading: Icon(
                 Icons.people_alt,
                 color: Colors.teal,
               ),
             title: Text('Laki-Laki',
             style: TextStyle(
               fontSize: 20.0,
               color: Colors.teal.shade900,
               fontFamily: 'Spider Home'),
             ),
             ),
          ),
          ],
        )),
      ),
    );
  }
}